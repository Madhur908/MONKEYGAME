var PLAY=1;
var END=0
var gameState=PLAY
var monkey , monkey_running,ground
var banana ,bananaImage, obstacle, obstacleImage
var FoodGroup, obstacleGroup
var score;
var bg

function preload(){

  
  monkey_running =            loadAnimation("sprite_0.png","sprite_1.png","sprite_2.png","sprite_3.png","sprite_4.png","sprite_5.png","sprite_6.png","sprite_7.png","sprite_8.png")
  
  bananaImage = loadImage("banana.png");
  obstaceImage = loadImage("obstacle.png");
  bg = loadImage("jungle.jpg")

}



function setup() {
  createCanvas(windowWidth,windowHeight)
  FoodGroup=createGroup()
  obstacleGroup=createGroup()
survivalTime=0;
  score=0;
monkey=createSprite(80,height-150,20 ,20)
monkey.addAnimation("moving",monkey_running)
monkey.scale=0.1

  
ground=createSprite(width/1.5,height-50,width,10) 
ground.visible=false
   ground.velocityX=-5 

bg.velocityX=ground.velocityX
  
}


function draw() {
  monkey.collide(ground)
background(bg)
  
  ground.x=ground.width/2
    
   
  if(gameState===PLAY){
     stroke("white")
  textSize(20)
  fill("white")
  text("score:"+score,100,80)
    
    
    
  monkey.visible=true
  
 if((touches.length>0||keyDown("space"))&&(monkey.scale===0.1||monkey.scale===0.12||monkey.scale===0.18||monkey.scale===0.14)&&(monkey.Y>=height-150)){
   monkey.velocityY=-30
   touches=[];
 }
    
  if(keyDown("space")&&monkey.y>=height-100){  
    monkey.velocityY=-30 
  }
  if(monkey.isTouching(FoodGroup)){
    score=score+2
    FoodGroup.destroyEach()     
  }
 

  switch(score){
    case 10 :monkey.scale=0.12
      break;
      case 20 :monkey.scale=0.14
      break;
    case 30:monkey.scale=0.18
      break;
      default:break;
  }

 bannanas() ; 
 obstacles();
  if(monkey.isTouching(obstacleGroup)&&monkey.scale===0.1){
    monkey.scale=0.05
    obstacleGroup.destroyEach()
    gameState=PLAY
    
  }
   if(monkey.isTouching(obstacleGroup)&&(monkey.scale===0.05||monkey.scale===0.12||monkey.scale===0.14||monkey.scale===0.18)){
     gameState=END
   }
     
   
  }  
  else if(gameState===END){
   monkey.velocityX=0;
banana.velocityX=0;
    obstacle.velocityX=0;
     ground.velocityX=0;
     obstacleGroup.setLifetimeEach(-1)
     FoodGroup.setLifetimeEach(-1)
     stroke("white")
     textSize(20)
     text("GAME OVER",200,200)
      survivalTime=0;
    if(keyDown("space")){
      reset()
    }
  }

    
   
 
  gravity();
 
  
drawSprites();  
}
function bannanas(){
  if(frameCount%80===0){
    banana=createSprite(400,height-100,20,20) 
    banana.addImage(bananaImage)
    banana.scale=0.1
    banana.y=Math.round(random(height-300,height-400))
    console.log(banana.y)
    banana.velocityX=-5
    banana.lifetime=100;
    FoodGroup.add(banana)
  }
}

function gravity(){
  monkey.velocityY=monkey.velocityY+2
}

function obstacles(){
  if(frameCount%100===0){
    obstacle=createSprite(400,height-100,20,20)
    obstacle.addImage(obstaceImage)
    
    obstacle.scale=0.2
    obstacle.depth=ground.depth
    obstacle.velocityX=-7
    obstacle.lifetime=100
    obstacleGroup.add(obstacle)
  }
}
function reset(){
  gameState=PLAY
  FoodGroup.destroyEach()
  obstacleGroup.destroyEach()
  survivalTime=0;
  score=0;
  monkey.scale=0.1
}


